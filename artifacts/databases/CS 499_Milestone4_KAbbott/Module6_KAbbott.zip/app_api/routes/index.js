const express = require('express');
const router = express.Router();
const tripsController = require('../controllers/trips');

// Trip routes
router.get('/trips', tripsController.getTrips);
router.get('/trips/:tripCode', tripsController.getTripByCode);
router.post('/trips', tripsController.addTrip); // (KA) Add new trip
router.put('/trips/:tripCode', tripsController.updateTrip); // (KA) Update trip
router.delete('/trips/:tripCode', tripsController.deleteTrip); // (KA) Delete trip

module.exports = router;
