const express = require('express');
const path = require('path');
const hbs = require('hbs');
const cors = require('cors');

// Load the Trip model and connect to MongoDB (KA)
require('./app_api/models/travlr');

// Load routes
const apiRouter = require('./app_api/routes/index'); // (KA) API routes
const travelerRoutes = require('./app_server/routes/travelerRoutes'); // (KA) Handlebars views

const app = express();
const PORT = 3000;

app.use(cors());               
app.use(express.json());        

// Set view engine and register Handlebars
app.set('view engine', 'hbs');
app.set('views', path.join(__dirname, 'app_server', 'views'));
hbs.registerPartials(path.join(__dirname, 'app_server', 'views', 'partials'));

// Serve static files
app.use(express.static(path.join(__dirname, 'public')));

// Mount API routes before web view routes
app.use('/api', apiRouter);   
app.use('/', travelerRoutes);   // For Handlebars site

// Start server
app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
