import { Component, Input } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { Trip } from '../trip';
import { Router } from '@angular/router';

@Component({
  selector: 'app-trip-card',
  standalone: true,
  imports: [CommonModule, DatePipe], 
  templateUrl: './trip-card.component.html',
  styleUrls: ['./trip-card.component.css']
})
export class TripCardComponent {
  @Input() trip!: Trip;

  constructor(private router: Router) {}

  editTrip() {
    if (this.trip && this.trip.code) {
      this.router.navigate(['/edit', this.trip.code]);
    }
  }
}

