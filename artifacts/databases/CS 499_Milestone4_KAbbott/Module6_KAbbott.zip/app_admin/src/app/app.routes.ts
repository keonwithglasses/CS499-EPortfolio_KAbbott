import { Routes } from '@angular/router';
import { TripListComponent } from './trip-list/trip-list.component';
import { TripEditComponent } from './trip-edit/trip-edit.component';
import { TripAddComponent } from './trip-add/trip-add.component';

export const routes: Routes = [
  { path: '', redirectTo: 'trips', pathMatch: 'full' }, // Redirect '' to /trips
  { path: 'trips', component: TripListComponent },      
  { path: 'edit/:code', component: TripEditComponent },
  { path: 'add', component: TripAddComponent }
];
