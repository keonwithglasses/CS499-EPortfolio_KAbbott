import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { TripDataService } from '../trip-data.service';
import { Trip } from '../trip';

@Component({
  selector: 'app-trip-add',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './trip-add.component.html',
  styleUrls: ['./trip-add.component.css']
})
export class TripAddComponent {
  trip: Trip = {
    code: '',
    name: '',
    length: '',
    start: '',
    resort: '',
    perPerson: '',
    image: '',
    description: ''
  };

  constructor(
    private tripDataService: TripDataService,
    private router: Router
  ) {}

  addTrip() {
    console.log('Add Trip button clicked:', this.trip); // (KA) Debugging

    // (KA) Prepare a new object to avoid mutating the bound `trip`
    const tripToSend = {
      ...this.trip,
      start: new Date(this.trip.start) // Ensure correct format for backend
    };

    this.tripDataService.addTrip(tripToSend).subscribe({
      next: () => {
        alert('Trip added!');
        this.router.navigate(['/']);
      },
      error: (err) => {
        console.error('Error adding trip:', err); // (KA) Log error
      }
    });
  }
}
