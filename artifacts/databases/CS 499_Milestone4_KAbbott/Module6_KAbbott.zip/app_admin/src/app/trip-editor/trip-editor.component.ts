import { Component, OnInit } from '@angular/core';
import { Trip } from '../trip';
import { TripDataService } from '../trip-data.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-trip-editor',
  templateUrl: './trip-editor.component.html',
  styleUrls: ['./trip-editor.component.css'],
  standalone: true
})
export class TripEditorComponent implements OnInit {
  trip: Trip = {
    code: '',
    name: '',
    length: '',
    start: '',
    resort: '',
    perPerson: '',
    image: '',
    description: ''
  };

  constructor(
    private tripDataService: TripDataService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
    const tripCode = this.route.snapshot.params['tripCode'];
    this.tripDataService.getTripByCode(tripCode).subscribe({
      next: (tripData) => (this.trip = tripData),
      error: (err) => console.error('Trip not found', err)
    });
  }

  updateTrip() {
    this.tripDataService.updateTrip(this.trip.code, this.trip).subscribe(() => {
      alert('Trip updated!');
      this.router.navigate(['/']);
    });
  }
}
