const mongoose = require('./db');
const Trip = mongoose.model('trips');
const tripsData = require('../../data/trips.json');

async function seedTrips() {
  try {
    // Clear existing trips
    await Trip.deleteMany({});
    console.log('Existing trips deleted.');

    // Insert new trips
    const insertedTrips = await Trip.insertMany(tripsData);
    console.log(`${insertedTrips.length} trips successfully stored.`);

    // Close DB connection
    mongoose.connection.close();
  } catch (error) {
    console.error('Error seeding trips:', error);
    mongoose.connection.close();
  }
}

seedTrips();
