const express = require('express');
const router = express.Router();
const travelController = require('../controllers/travel'); // Import controller

// Using the controller functions instead of defining logic in routes
router.get('/', travelController.renderHomePage);
router.get('/about', travelController.renderAboutPage);
router.get('/contact', travelController.renderContactPage);
router.get('/meals', travelController.renderMealsPage);
router.get('/news', travelController.renderNewsPage);
router.get('/rooms', travelController.renderRoomsPage);
router.get('/travel', travelController.renderTravelPage);

module.exports = router;

