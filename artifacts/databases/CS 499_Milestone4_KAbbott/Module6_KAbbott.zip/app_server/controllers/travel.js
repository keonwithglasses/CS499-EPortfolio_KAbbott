const axios = require('axios');

exports.renderTravelPage = async (req, res) => {
  try {
    const response = await axios.get('http://localhost:3000/api/trips');
    const trips = response.data;

    res.render('travel', {
      title: "Travel Info",
      trips
    });
  } catch (err) {
    console.error('Error fetching trips from API:', err);
    res.render('travel', {
      title: "Travel Info",
      trips: [],
      error: "Could not load trip data from API."
    });
  }
};
